<?php
class Product_filter_model extends CI_Model
{
	function fetch_filter_brand($se='')
	{
		//$this->db->distinct();
		$this->db->select('products_data.brand_id,brand.name,count(*) as num');
		$this->db->from('products_data');
		$this->db->join('brand','brand.id=products_data.brand_id');
		$this->db->where('products_data.status', '1');
		$this->db->where('products_data.name like "%'.$se.'%" || products_data.description like "%'.$se.'%"');
		$this->db->group_by('products_data.brand_id');
		$this->db->order_by('products_data.id', 'DESC');
		return $this->db->get();
	}
	function fetch_filter_cat($se)
	{
	$cat=array();
		$xc=$this->db->select('*')
		          ->from('categories')
		          ->where('parent_id',$se)
		          ->order_by('categories.name', 'ASC')->get();
   foreach($xc->result_array() as $rows){
   	   $cat[$se][$rows['id']]['id']=$rows['id'];
	    $cat[$se][$rows['id']]['name']=$rows['name'];
		$xc1=$this->db->select('*')
		          ->from('categories')
		          ->where('parent_id',$rows['id'])
		          ->order_by('categories.name', 'ASC')->get();
    if($xc1->num_rows()>0){
	foreach($xc1->result_array() as $d){
	$cat[$rows['id']][$d['id']]['id']=$d['id'];
	$cat[$rows['id']][$d['id']]['name']=$d['name'];
	$xc2=$this->db->select('*')
		          ->from('categories')
		          ->where('parent_id',$d['id'])
		          ->order_by('categories.name', 'ASC')->get();
	if($xc2->num_rows()>0){
	foreach($xc2->result_array() as $d1){
	$cat[$d['id']][$d1['id']]['id']=$d1['id'];
	$cat[$d['id']][$d1['id']]['name']=$d1['name'];
	$xc3=$this->db->select('*')
		          ->from('categories')
		          ->where('parent_id',$d1['id'])
		          ->order_by('categories.name', 'ASC')->get();
	if($xc3->num_rows()>0){
	foreach($xc3->result_array() as $d2){
	$cat[$d1['id']][$d2['id']]['id']=$d2['id'];
	$cat[$d1['id']][$d2['id']]['name']=$d2['name'];
	}}
	}}
  } }
  }
  return $cat;
	}

		function cat_list($se)
	{
	$x=implode(",",$se);
	$cat[]=$x;
		$xc=$this->db->select('*')
		          ->from('categories')
		          ->where('parent_id IN ('.$x.')')->get();
   if($xc->num_rows()>0){
   foreach($xc->result_array() as $d){
   	   $cat[]=$d['id'];
   } }
    $y=implode(",",$cat);
   $xc1=$this->db->select('*')
		          ->from('categories')
		          ->where('parent_id IN ('.$y.')')->get();
   if($xc1->num_rows()>0){
   foreach($xc1->result_array() as $d1){
   	   $cat[]=$d1['id'];
   } }
   $y1=implode(",",$cat);
   $xc11=$this->db->select('*')
		          ->from('categories')
		          ->where('parent_id IN ('.$y1.')')->get();
   if($xc11->num_rows()>0){
   foreach($xc11->result_array() as $d11){
   	   $cat[]=$d11['id'];
   } }
   $y11=implode(",",$cat);
   $xc111=$this->db->select('*')
		          ->from('categories')
		          ->where('parent_id IN ('.$y11.')')->get();
   if($xc111->num_rows()>0){
   foreach($xc111->result_array() as $d111){
   	   $cat[]=$d111['id'];
   } }
array_unique($cat);

  return $cat;
	}


	function fetch_filter_attribute($se='')
	{
	$at=array();
	$at_val=array();
	$x=$this->db->select('*')->from('attribute')->get();
	foreach($x->result_array() as $row){
	$att=$row['id'];
	
	$val=$this->db->select('attribute_value.id,attribute_value.name,count(*) as num')->from('attribute_value')
		        ->join('attribute','attribute.id=attribute_value.attribute_id')
		        ->join('products_attribute','products_attribute.attribute_value_id=attribute_value.id')
		        ->join('products_data','products_data.id=products_attribute.products_id')
		        ->where('products_data.status', '1')
		        ->where('attribute.id="'.$att.'" and (products_data.name like "%'.$se.'%" || products_data.description like "%'.$se.'%")')
				->group_by('attribute_value.id')
		        ->order_by('attribute_value.name', 'ASC')->get();
				if($val->num_rows()>0){
				$at[$row['id']]=$row['name'];
				$i=0;
       foreach($val->result_array() as $rrw){
	   if($rrw['num']>0){
	   $at[$row['id']]=$row['name'];
	   $at_val[$att][$rrw['id']][$i]['name']=$rrw['name'].'!!!'.$rrw['num'];
	    $at_val[$att][$rrw['id']][$i]['id']=$rrw['id'];
	   $i++;
	   }
	   } }

		}
		return array("main"=>$at,"sub"=>$at_val);
	}

	function make_query($minimum_price, $maximum_price, $brand, $ram, $storage,$cat,$se,$sort)
	{
	$catie=implode(",",$cat);
		$query = "
		SELECT distinct(products_data.id),products_data.*,brand.name as brand FROM products_data inner join brand on brand.id=products_data.brand_id";
		if(isset($storage) and $storage!=''){
		$query .= " inner join products_attribute on products_attribute.products_id=products_data.id";
		}
		$query .= " WHERE status=1 and stock=1 and (products_data.name like '%".$se."%' || products_data.description like '%".$se."%')	";	
		if(count($cat)>0){
			$query.=" and cat_id IN (".$catie.") ";
		}
		if(isset($minimum_price, $maximum_price) && !empty($minimum_price) && !empty($maximum_price))
		{
			$query .= "	 AND sale_price BETWEEN '".$_POST["minimum_price"]."' AND '".$_POST["maximum_price"]."'";
		}

		if(isset($brand) and $brand!='')
		{
			$brand_filter = implode("','", $brand);
			$query .= "
			 AND brand_id IN('".$brand_filter."')";
		}
		if(isset($ram) and $ram!='')
		{
			$ram_filter = implode("','", $ram);
			$query .= "
			 AND stock='".$ram_filter."'";
		}
		if(isset($storage) and $storage!='')
		{
			$storage_filter = implode("','", $storage);
			$query .= "
			 AND products_attribute.attribute_value_id  IN('".$storage_filter."')";
		}
	  if($sort=='price-desc')
	  $query.=" order by products_data.sale_price DESC";
	  else if($sort=='price')
	  $query.=" order by products_data.sale_price ASC";
	  else
	  $query.=" order by products_data.id DESC";

		return $query;
	}

	function fetch_data($limit, $start, $minimum_price, $maximum_price, $brand, $ram, $storage,$cat,$se,$sort)
	{
		$query = $this->make_query($minimum_price, $maximum_price, $brand, $ram, $storage,$cat,$se,$sort);
		$query .= ' LIMIT '.$start.', ' . $limit;

		$data = $this->db->query($query );

		$output = '';
		if($data->num_rows() > 0)
		{
			foreach($data->result_array() as $row)
			{
			if($row['stock']==1 || $row['stock']==1)
			$x='<span style="color:green;font-weight:bold;">In-stock</span>';
			else
			$x='<span style="color:red;font-weight:bold;">Out-stock</span>';

			$output.='<div class="col-7 col-md-4" style="    position: relative;
    display: -webkit-box!important;
    display: flex!important;
    height: auto;
    
    padding: 20px 20px 0;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    flex-direction: column;
    overflow: hidden;
    border: 1px solid #ebebeb;
    border-radius: 2px;
    -webkit-transition: .2s ease-in-out;
    transition: .2s ease-in-out;">
							<div class="grid_item">
								<figure>
									<a href="'.$row['lnk'].'" target="_blank">
										<img class="img-fluid lazy" src="'. $row['image'] .'" data-src="'. $row['image'] .'" alt="" style="width:220px;height:220px !important;">
									</a>								
								</figure>
								<a href="'.$row['lnk'].'">
									<h3>'. $row['name'] .'</h3>
								</a><br>
								<small style="color:green;">Brand :'. $row['brand'] .'</small>
								<div class="price_box">
									<span class="new_price">INR '.$row['sale_price'].'</span>
									
								</div>								
							</div>
							<!-- /grid_item -->
						</div>';
				/*$output .= '
				<div class="col-sm-4 col-lg-3 col-md-3">
					<a href="'.$row['lnk'].'" target="_blank"><div style="border:1px solid #ccc; border-radius:5px; padding:16px; margin-bottom:16px; height:450px;">
					<img src="'. $row['image'] .'" alt="" class="img-responsive" style="min-height:140px;" >
					<p align="center" style="min-height:140px;padding-top:15px;"><strong><a href="#">'. $row['name'] .'</a></strong></p>
					<h4 style="text-align:center;" class="text-danger" >INR '. $row['sale_price'] .'</h4>
					<p>Brand : '.  $row['brand'].' <br />
					Size : '. $row['size'] .' <br />
					Weight : '. $row['shipping_weight'] .' lb<br />
					Availability : '. $x .'  </p>
					</div></a>
				</div>
				';*/
			}
		}
		else
		{
			$output = '<h3>No Data Found</h3>';
		}
		return array('data'=>$output);
	}

	function count_all($minimum_price, $maximum_price, $brand, $ram, $storage,$cat,$se,$sort)
	{
		$query = $this->make_query($minimum_price, $maximum_price, $brand, $ram, $storage,$cat,$se,$sort);
		$d=explode('@',$query);
		$data = $this->db->query($d[0]);
		return $data->num_rows();
	}

}
?>