<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_filter extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_filter_model');
	}
	
	function index($arg='')
	{
	
	    $se=$this->input->post('se');
		$data['brand_data'] = $this->product_filter_model->fetch_filter_brand($se);
		$data['cat_data'] = $this->product_filter_model->fetch_filter_cat('0');
		$data['attribute_data'] = $this->product_filter_model->fetch_filter_attribute($se);
		$data['timew'] = time();
		 redirect(base_url('product_filter/home/').time(), 'refresh');
	}
	function home($arg='')
	{
	$this->load->library('session');
	    $se=$this->input->get('se');
		if($arg=='')
		$time=time();
		else
		$time=$arg;
		$this->session->set_userdata('se'.$time,$se);
		
		$data['brand_data'] = $this->product_filter_model->fetch_filter_brand($se);
		$data['cat_data'] = $this->product_filter_model->fetch_filter_cat('0');
		$data['attribute_data'] = $this->product_filter_model->fetch_filter_attribute($se);
		$data['timew'] = $time;
		$this->load->view('product_filter', $data);
	}

	function fetch_data()
	{
		sleep(2);
		
		$time = $this->input->post('timew');
		$minimum_price = $this->input->post('minimum_price');
		$maximum_price = $this->input->post('maximum_price');
		$brand = $this->input->post('brand');
		$sort = $this->input->post('sort');
		$cat = $this->input->post('cat');
		$se = $this->input->get('se');
		$ram = $this->input->post('ram');
		$storage = $this->input->post('storage');
		$this->session->set_userdata('minimum_price'.$time,$minimum_price);
		$this->session->set_userdata('maximum_price'.$time,$maximum_price);
		$this->session->set_userdata('brand'.$time,$brand);
		$this->session->set_userdata('cat'.$time,$cat);
		$this->session->set_userdata('se'.$time,$se);
		$this->session->set_userdata('ram'.$time,$ram);
		$this->session->set_userdata('storage'.$time,$storage);
		$this->load->library("pagination");
		$config = array();
		$config["base_url"] = "#";
		$config["total_rows"] = $this->product_filter_model->count_all($minimum_price, $maximum_price, $brand, $ram, $storage,$cat,$se,$sort);
		$config["per_page"] = 20;
		$config["uri_segment"] = 3;
		$config["use_page_numbers"] = TRUE;
		$config["full_tag_open"] = '<ul class="pagination">';
		$config["full_tag_close"] = '</ul>';
		$config["first_tag_open"] = '<li>';
		$config["first_tag_close"] = '</li>';
		$config["last_tag_open"] = '<li>';
		$config["last_tag_close"] = '</li>';
		$config['next_link'] = '&gt;';
		$config["next_tag_open"] = '<li>';
		$config["next_tag_close"] = '</li>';
		$config["prev_link"] = "&lt;";
		$config["prev_tag_open"] = "<li>";
		$config["prev_tag_close"] = "</li>";
		$config["cur_tag_open"] = "<li class='active'><a href='#'>";
		$config["cur_tag_close"] = "</a></li>";
		$config["num_tag_open"] = "<li>";
		$config["num_tag_close"] = "</li>";
		$config["num_links"] = 3;
		$this->pagination->initialize($config);
		$page = $this->uri->segment('3');
		$start = ($page - 1) * $config["per_page"];
		
		$output = array(
			'pagination_link'		=>	$this->pagination->create_links(),
			'product_list'			=>	$this->product_filter_model->fetch_data($config["per_page"], $start, $minimum_price, $maximum_price, $brand, $ram, $storage,$cat,$se,$sort)
		);
		echo json_encode($output);
	}
	
}

?>