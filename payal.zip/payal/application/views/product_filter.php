
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ansonika">
    <title>Product Search</title>
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<link href = "<?php echo base_url(); ?>asset/jquery-ui.css" rel = "stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo base_url(); ?>asset/style.css" rel="stylesheet">

    <!-- Favicons-->
    
	
    <!-- GOOGLE WEB FONT -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo base_url(); ?>asset/css/bootstrap.custom.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>asset/css/style.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
    <link href="<?php echo base_url(); ?>asset/css/listing.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo base_url(); ?>asset/css/custom.css" rel="stylesheet">

</head>

<body>
	
	<div id="page" class="theia-exception">
		
	<header class="version_1">
		<div class="layer"></div><!-- Mobile menu overlay mask -->
		<div class="main_header">
			<div class="container">
				<div class="row small-gutters">
					<div class="col-xl-3 col-lg-3 d-lg-flex align-items-center">
						<div id="logo">
							<a href="#" style="font-size: 26px;color: #fff;font-weight: bold;">Payal</a>
						</div>
					</div>
					<nav class="col-xl-6 col-lg-7">
						<a class="open_close" href="javascript:void(0);">
							<div class="hamburger hamburger--spin">
								<div class="hamburger-box">
									<div class="hamburger-inner"></div>
								</div>
							</div>
						</a>
						<!-- Mobile menu button -->
						<div class="main-menu">
							<div id="header_menu">
								<a href="#" style="font-size: 26px;color: #fff;font-weight: bold;">Payal</a>
								<a href="#" class="open_close" id="close_in"><i class="ti-close"></i></a>
							</div>
							<ul>
								<li class="#">
									<a href="#" class="show-submenu">Home</a>
									
								</li>
								<li class="megamenu ">
									<a href="#" class="show-submenu-mega">Electronics</a>
									
								</li>
								<li class="#">
									<a href="#" class="show-submenu">Furniture</a>
								</li>
								<li>
									<a href="#">Sports</a>
								</li>
								<li>
									<a href="#">Offer Zone</a>
								</li>
							</ul>
						</div>
						<!--/main-menu -->
					</nav>
					<div class="col-xl-3 col-lg-2 d-lg-flex align-items-center justify-content-end text-end">
						<a class="phone_top" href="#"><strong><span>Need Help?</span>+XX XXX-XX-XXX</strong></a>
					</div>
				</div>
				<!-- /row -->
			</div>
		</div>
		<!-- /main_header -->

		
		<div class="main_nav inner">
			<div class="container">
				<div class="row small-gutters">
					<div class="col-xl-3 col-lg-3 col-md-3">
						<nav class="categories">
							<ul class="clearfix">
								<li><span>
										<a href="#">
											<span class="hamburger hamburger--spin">
												<span class="hamburger-box">
													<span class="hamburger-inner"></span>
												</span>
											</span>
											Categories
										</a>
									</span>
									<div id="menu">
										<ul>
										<?php foreach($cat_data as $c=>$cc){
										
										foreach($cc as $k=>$kk){
										?>
											<li><span><a href="#"><?=$kk['name']?></a></span>
											<?php 
										if(is_array($cat_data[$kk['id']]) and sizeof($cat_data[$kk['id']]>0)){
										echo '<ul>';
										foreach($cat_data[$kk['id']] as $k1=>$kk1){
										?>											
													<li><a href="#"><?=$kk1['name']?></a>                                            
											<?php 
										if(is_array($cat_data[$kk1['id']]) and sizeof($cat_data[$kk1['id']]>0)){
										echo '<ul>';
										foreach($cat_data[$kk1['id']] as $k12=>$kk12){
										?>
										<li><a href="#"><?=$kk12['name']?></a> 
										<?php 
										if(is_array($cat_data[$kk12['id']]) and sizeof($cat_data[$kk12['id']]>0)){
										echo '<ul>';
										foreach($cat_data[$kk12['id']] as $k123=>$kk123){
										?>
										<li><a href="#"><?=$kk123['name']?></a> </li>
										<?php }	
										echo '</ul></li>';
										}else{ echo '</li>';} ?>

										<?php }	
										echo '</ul></li>';
										}else{ echo '</li>';} ?>
										
										<?php }	
										echo '</ul></li>';
										}else{ echo '</li>';} ?>
											<?php } }?>
										</ul>
									</div>
								</li>
							</ul>
						</nav>
					</div>
					<div class="col-xl-5 col-lg-7 col-md-6 d-none d-md-block">
						<form id="frm" name="frm" action="" method="get">	<div class="custom-search-input">
					
		<input type="text"name="se" placeholder="Search over 10,000 products" id="se" class="common_selector form-control" value="<?=$this->session->userdata('se'.$timew)?>">
							<button type="submit"><i class="header-icon_search_custom"></i></button>
						</div></form>
					</div>
					<div class="col-xl-3 col-lg-2 col-md-3">
						
					</div>
				</div>
				<!-- /row -->
			</div>
			<div class="search_mob_wp">
				<input type="text" class="form-control" placeholder="Search over 10.000 products">
				<input type="submit" class="btn_1 full-width" value="Search">
				<input type="hidden" name="tme" id="tme" value="<?=$timew?>">
			</div>
			<!-- /search_mobile -->
		</div>
		<!-- /main_nav -->
	</header>
	<!-- /header -->
		
	<main>
		
		<!-- /top_banner -->
			<div id="stick_here"></div>		
			<div class="toolbox elemento_stick">
				<div class="container">
				<ul class="clearfix">
					<li>
						<div class="sort_select">
							<select name="sortx" id="sortx" class="common_selector sort" >
                                    <option value="popularity" selected="selected" >Sort by popularity</option>
                                    <option value="rating">Sort by average rating</option>
                                    <option value="date">Sort by newness</option>
                                    <option value="price">Sort by price: low to high</option>
                                    <option value="price-desc">Sort by price: high to 
							</select>
						</div>

					</li>
					<li>
						<a href="#0"><i class="ti-view-grid"></i></a>
						<a href="#"><i class="ti-view-list"></i></a>
					</li>
					<li>
						<a href="#0" class="open_filters">
							<i class="ti-filter"></i><span>Filters</span>
						</a>
					</li>
				</ul>
				</div>
			</div>
			<!-- /toolbox -->
			
			<div class="container margin_30">
			
			<div class="row">
				<aside class="col-lg-3" id="sidebar_fixed">
				    <div class="filter_col">
				        <div class="inner_bt"><a href="#" class="open_filters"><i class="ti-close"></i></a></div>

						<div class="filter_type version_2">
				            <h4><a href="#filter_100" data-bs-toggle="collapse" class="closed">Category</a></h4>
				            <div class="collapse" id="filter_100">
				                <ul><?php
								$xx1=$this->session->userdata('cat'.$timew);
								foreach($cat_data as $c=>$cc){
										
										foreach($cc as $k=>$kk){?>
					                    <li>
				                        <label class="container_check "> <?php echo $kk['name']; ?> 
				                            <input <?=(in_array($kk['id'],$xx1))?'checked="checked"':'';?> type="checkbox" name="c<?=$kk['id']?>" id="c<?=$kk['id']?>" class="common_selector cat" value="<?php echo $kk['id']; ?>">
				                            <span class="checkmark"></span>
				                        </label></li><?php }}?></ul>
				                    </li>
				                
				                </ul>
				            </div>
				            <!-- /filter_type -->
				        </div>


						<div class="filter_type version_2">
				            <h4><a href="#filter_100" data-bs-toggle="collapse" class="opened">Price</a></h4>
				            <div class="collapse show" id="filter_100">
				                <ul>
					                    <li>
				                        <label class="container_check ">	<input type="hidden" id="hidden_minimum_price" value="0" />
				                     	<input type="hidden" id="hidden_maximum_price" value="10000" />
				                           <p id="price_show">0 - 10000</p>
	                                      <div id="price_range"></div>
				                        </label>
				                    </li>
				                
				                </ul>
				            </div>
				            <!-- /filter_type -->
				        </div>

				        <div class="filter_type version_2">
				            <h4><a href="#filter_1" data-bs-toggle="collapse" class="closed">Brand</a></h4>
				            <div class="collapse " id="filter_1">
				                <ul>
								<?php							
								$x1=$this->session->userdata('brand'.$timew);
					foreach($brand_data->result_array() as $row)
					{
					 
					?>
				                    <li>
				                        <label class="container_check "> <?php echo $row['name']; ?> <small><?php echo $row['num']; ?></small>
				                            <input <?=(in_array($row['brand_id'],$x1))?'checked="checked"':'';?> type="checkbox" name="b<?=$row['brand_id']?>" id="b<?=$row['brand_id']?>" class="common_selector brand" value="<?php echo $row['brand_id']; ?>">
				                            <span class="checkmark"></span>
				                        </label>
				                    </li>
				                    <?php }?>
				                </ul>
				            </div>
				            <!-- /filter_type -->
				        </div>
                        <?php $r=10;
						$x12=$this->session->userdata('storage'.$timew);
						foreach($attribute_data['main'] as $d=>$dd){?>
				        <!-- /filter_type -->
				        <div class="filter_type version_2">
				            <h4><a href="#filter_<?=$r?>" data-bs-toggle="collapse" class="closed"><?=$dd?></a></h4>
				            <div class="collapse " id="filter_<?=$r?>">
				                <ul>
								<?php foreach($attribute_data['sub'][$d] as $v=>$vv){
								foreach($vv as $y=>$yy){
								$x=explode('!!!',$yy['name']);?>
				                    <li>
				                        <label class="container_check"><?=$x[0]?><small><?=$x[1]?></small>
				                     <input <?=(in_array($yy['id'],$x12))?'checked="checked"':'';?> type="checkbox" name="s<?=$yy['id']?>" id="s<?=$yy['id']?>" class="common_selector storage" value="<?=$yy['id']?>" >
				                            <span class="checkmark"></span>
				                        </label>
				                    </li>
				               <?php } }?>
				                  
				                </ul>
				            </div>
				        </div>

				        <!-- /filter_type -->
						<?php $r++; }?>
				        <div class="filter_type version_2">
				            <h4><a href="#filter_300" data-bs-toggle="collapse" class="closed">Availability</a></h4>
				            <div class="collapse" id="filter_300">
				                <ul>
				                    <li>
				                        <label class="container_check">Out of Stock 
				                            <input type="checkbox" class="common_selector ram" value="0" >
				                            <span class="checkmark"></span>
				                        </label>
				                    </li>
				                   
				                </ul>
				            </div>
				        </div>
				        <!-- /filter_type -->
				      
				        <!-- /filter_type -->
				        
				    </div>
				</aside>
				<!-- /col -->
				<div class="col-lg-9">
					<div class="row small-gutters filter_data">
					
					</div>
					<!-- /row -->
					<div class="pagination__wrapper">
						<div align="center" id="pagination_link"></div>
					</div>
				</div>
				<!-- /col -->
			</div>
			<!-- /row -->			
				
		</div>
		<!-- /container -->
	</main>
	<!-- /main -->
	
	<footer class="revealed">
		<div class="container">
		
			<!-- /row-->
			<hr>
			
		</div>
	</footer>
	<!--/footer-->
	</div>
	<!-- page -->
	
	<div id="toTop"></div><!-- Back to top button -->
	
	<!-- COMMON SCRIPTS -->
    <script src="<?php echo base_url(); ?>asset/js/common_scripts.min.js"></script>
    <script src="<?php echo base_url(); ?>asset/js/main.js"></script>
	
	<!-- SPECIFIC SCRIPTS -->
	<script src="<?php echo base_url(); ?>asset/js/sticky_sidebar.min.js"></script>
	<script src="<?php echo base_url(); ?>asset/js/specific_listing.js"></script>
	<style>
#loading
{
	text-align:center; 
	background: url('<?php echo base_url(); ?>asset/loader.gif') no-repeat center; 
	height: 150px;
}
</style>

<script>
$.noConflict();
$(document).ready(function(){

	filter_data(1);

	function filter_data(page,order='')
	{

		$('.filter_data').html('<div id="loading" style="" ></div>');
		var action = 'fetch_data';
		//var page = 1;
		var minimum_price = $('#hidden_minimum_price').val();
		var maximum_price = $('#hidden_maximum_price').val();
		var brand = get_filter('brand');
		var ram = get_filter('ram');
		var sort =  $('#sortx :selected').val();;
		var se = $('#se').val();
		var tme = $('#tme').val();
		var storage = get_filter('storage');
		var cat = get_filter('cat');
		var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?se='+se+'&minimum_price='+minimum_price+'&maximum_price='+maximum_price+'&brand='+brand+'&ram='+ram+'&storage='+storage+'&cat='+cat+'&sort='+sort;
        window.history.pushState({ path: newurl }, '', newurl);
		$.ajax({
			url:"<?php echo base_url(); ?>product_filter/fetch_data/"+page,
			method:"POST",
			dataType:"JSON",
			data:{sort:sort,cat:cat,action:action, minimum_price:minimum_price, maximum_price:maximum_price, brand:brand, ram:ram, storage:storage,se:se,timew:tme},
			success:function(data)
			{
			
				$('.filter_data').html(data.product_list.data);
				$('#pagination_link').html(data.pagination_link);
			}
		})
	}

	$('#price_range').slider({
		range:true,
		min:0,
		max:10000,
		values:[0, 10000],
		step: 500,
		stop:function(event, ui){
			//$('#price_show').show();
			$('#price_show').html(ui.values[0] + ' - ' + ui.values[1]);
			$('#hidden_minimum_price').val(ui.values[0]);
			$('#hidden_maximum_price').val(ui.values[1]);
			filter_data(1);
		}
	});

	function get_filter(class_name)
	{
		var filter = [];
		$('.'+class_name+':checked').each(function(){
			filter.push($(this).val());
		});
		return filter;
	}

	$(document).on("click", ".pagination li a", function(event){
		event.preventDefault();
		var page = $(this).data("ci-pagination-page");
		filter_data(page);
	});

	$('.common_selector').click(function(){
        filter_data(1);
    });



});
</script>
	
</body>
</html>